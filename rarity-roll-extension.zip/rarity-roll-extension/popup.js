(function () {
  // ---------- Elements deck ----------
  const ELEMENTS_RAW = [
    [1,"H","Hydrogen","nonmetal"],[2,"He","Helium","noble"],[3,"Li","Lithium","alkali"],
    [4,"Be","Beryllium","alkaline"],[5,"B","Boron","metalloid"],[6,"C","Carbon","nonmetal"],
    [7,"N","Nitrogen","nonmetal"],[8,"O","Oxygen","nonmetal"],[9,"F","Fluorine","halogen"],
    [10,"Ne","Neon","noble"],[11,"Na","Sodium","alkali"],[12,"Mg","Magnesium","alkaline"],
    [13,"Al","Aluminium","post-transition"],[14,"Si","Silicon","metalloid"],[15,"P","Phosphorus","nonmetal"],
    [16,"S","Sulfur","nonmetal"],[17,"Cl","Chlorine","halogen"],[18,"Ar","Argon","noble"],
    [19,"K","Potassium","alkali"],[20,"Ca","Calcium","alkaline"],[21,"Sc","Scandium","transition"],
    [22,"Ti","Titanium","transition"],[23,"V","Vanadium","transition"],[24,"Cr","Chromium","transition"],
    [25,"Mn","Manganese","transition"],[26,"Fe","Iron","transition"],[27,"Co","Cobalt","transition"],
    [28,"Ni","Nickel","transition"],[29,"Cu","Copper","transition"],[30,"Zn","Zinc","transition"],
    [31,"Ga","Gallium","post-transition"],[32,"Ge","Germanium","metalloid"],[33,"As","Arsenic","metalloid"],
    [34,"Se","Selenium","nonmetal"],[35,"Br","Bromine","halogen"],[36,"Kr","Krypton","noble"],
    [37,"Rb","Rubidium","alkali"],[38,"Sr","Strontium","alkaline"],[39,"Y","Yttrium","transition"],
    [40,"Zr","Zirconium","transition"],[41,"Nb","Niobium","transition"],[42,"Mo","Molybdenum","transition"],
    [43,"Tc","Technetium","transition"],[44,"Ru","Ruthenium","transition"],[45,"Rh","Rhodium","transition"],
    [46,"Pd","Palladium","transition"],[47,"Ag","Silver","transition"],[48,"Cd","Cadmium","transition"],
    [49,"In","Indium","post-transition"],[50,"Sn","Tin","post-transition"],[51,"Sb","Antimony","metalloid"],
    [52,"Te","Tellurium","metalloid"],[53,"I","Iodine","halogen"],[54,"Xe","Xenon","noble"],
    [55,"Cs","Caesium","alkali"],[56,"Ba","Barium","alkaline"],[57,"La","Lanthanum","lanthanide"],
    [58,"Ce","Cerium","lanthanide"],[59,"Pr","Praseodymium","lanthanide"],[60,"Nd","Neodymium","lanthanide"],
    [61,"Pm","Promethium","lanthanide"],[62,"Sm","Samarium","lanthanide"],[63,"Eu","Europium","lanthanide"],
    [64,"Gd","Gadolinium","lanthanide"],[65,"Tb","Terbium","lanthanide"],[66,"Dy","Dysprosium","lanthanide"],
    [67,"Ho","Holmium","lanthanide"],[68,"Er","Erbium","lanthanide"],[69,"Tm","Thulium","lanthanide"],
    [70,"Yb","Ytterbium","lanthanide"],[71,"Lu","Lutetium","lanthanide"],[72,"Hf","Hafnium","transition"],
    [73,"Ta","Tantalum","transition"],[74,"W","Tungsten","transition"],[75,"Re","Rhenium","transition"],
    [76,"Os","Osmium","transition"],[77,"Ir","Iridium","transition"],[78,"Pt","Platinum","transition"],
    [79,"Au","Gold","transition"],[80,"Hg","Mercury","transition"],[81,"Tl","Thallium","post-transition"],
    [82,"Pb","Lead","post-transition"],[83,"Bi","Bismuth","post-transition"],[84,"Po","Polonium","metalloid"],
    [85,"At","Astatine","halogen"],[86,"Rn","Radon","noble"],[87,"Fr","Francium","alkali"],
    [88,"Ra","Radium","alkaline"],[89,"Ac","Actinium","actinide"],[90,"Th","Thorium","actinide"],
    [91,"Pa","Protactinium","actinide"],[92,"U","Uranium","actinide"],[93,"Np","Neptunium","actinide"],
    [94,"Pu","Plutonium","actinide"],[95,"Am","Americium","actinide"],[96,"Cm","Curium","actinide"],
    [97,"Bk","Berkelium","actinide"],[98,"Cf","Californium","actinide"],[99,"Es","Einsteinium","actinide"],
    [100,"Fm","Fermium","actinide"],[101,"Md","Mendelevium","actinide"],[102,"No","Nobelium","actinide"],
    [103,"Lr","Lawrencium","actinide"],[104,"Rf","Rutherfordium","transition"],[105,"Db","Dubnium","transition"],
    [106,"Sg","Seaborgium","transition"],[107,"Bh","Bohrium","transition"],[108,"Hs","Hassium","transition"],
    [109,"Mt","Meitnerium","transition"],[110,"Ds","Darmstadtium","transition"],[111,"Rg","Roentgenium","transition"],
    [112,"Cn","Copernicium","transition"],[113,"Nh","Nihonium","post-transition"],[114,"Fl","Flerovium","post-transition"],
    [115,"Mc","Moscovium","post-transition"],[116,"Lv","Livermorium","post-transition"],[117,"Ts","Tennessine","halogen"],
    [118,"Og","Oganesson","noble"]
  ];
  const ELEMENTS = ELEMENTS_RAW.map(([z, sym, name, cat]) => ({ z, sym, name, cat }));

  const LEGENDARY_SYM = new Set(["Tc", "Pm", "At", "Fr", "Ra"]);
  const RARE_MID_TRANSITION = [39,40,41,42,44,45,46,47,48];

  function elementRarity(el) {
    if (el.z >= 104) return "legendary";
    if (LEGENDARY_SYM.has(el.sym)) return "legendary";
    if (el.cat === "lanthanide" || el.cat === "actinide") return "epic";
    if (el.cat === "noble") return (el.z === 2 || el.z === 10 || el.z === 18) ? "common" : "epic";
    if (el.cat === "halogen") return (el.sym === "F" || el.sym === "Cl") ? "uncommon" : "rare";
    if (el.cat === "metalloid") return "rare";
    if (el.cat === "transition") {
      if (el.z >= 72) return "rare";
      if (RARE_MID_TRANSITION.includes(el.z)) return "rare";
      return "uncommon";
    }
    if (el.cat === "post-transition") return ["Ga","In","Tl","Bi"].includes(el.sym) ? "rare" : "uncommon";
    if (el.cat === "alkali") return ["Rb","Cs"].includes(el.sym) ? "rare" : "common";
    if (el.cat === "alkaline") {
      if (el.sym === "Be") return "rare";
      if (el.sym === "Sr" || el.sym === "Ba") return "uncommon";
      return "common";
    }
    return ["Se"].includes(el.sym) ? "uncommon" : "common";
  }
  ELEMENTS.forEach(el => el.rarity = elementRarity(el));

  const ELEMENT_FACTS = {
    H: "The universe's first and lightest atom — most of everything is made of it.",
    He: "So light it escapes Earth's gravity into space over time.",
    C: "Forms more known compounds than any other element — the backbone of life.",
    O: "Makes up about a fifth of the air you're breathing right now.",
    Fe: "The core of the Earth is mostly this, spinning and making our magnetic field.",
    Au: "Dense enough that all the gold ever mined would fit in a modest cube.",
    Ag: "The best natural conductor of electricity and heat of any metal.",
    U: "Its slow decay is one of the ways geologists date the age of rocks.",
    Pu: "Man-made in reactors — a few kilograms once powered a nuclear device.",
    Tc: "The lightest element with no stable isotopes at all — always radioactive.",
    Fr: "So unstable that at any moment, less than a gram likely exists on Earth.",
    Og: "Synthesized atom by atom — only a handful have ever been made.",
    Hg: "The only metal that's liquid at room temperature.",
    Ne: "Glows a vivid orange-red when electrified — the original neon sign.",
    Xe: "Used to fuel some spacecraft ion engines, propelling them for years.",
    Pt: "Rarer than gold and prized for resisting corrosion almost entirely.",
    W: "Has the highest melting point of any metal — once lit filament bulbs.",
    Ti: "As strong as steel at half the weight — a favorite of aerospace engineers."
  };
  const ELEMENT_CAT_FACT = {
    nonmetal: "A nonmetal — brittle or gaseous, and essential to how chemistry builds molecules.",
    noble: "A noble gas — famously unreactive, content to drift on its own.",
    alkali: "An alkali metal — soft, silvery, and eager to react the moment it meets water.",
    alkaline: "An alkaline earth metal — sturdy and reactive, common in minerals underfoot.",
    metalloid: "A metalloid — straddling the line between metal and nonmetal.",
    "post-transition": "A post-transition metal — softer and lower-melting than its transition-metal cousins.",
    transition: "A transition metal — dense, lustrous, and a workhorse of industry.",
    halogen: "A halogen — sharp-smelling and fiercely reactive in its pure form.",
    lanthanide: "A lanthanide — quietly essential to magnets, lasers, and phone screens.",
    actinide: "An actinide — heavy, radioactive, and mostly synthesized rather than mined."
  };

  // ---------- Countries deck ----------
  // columns: code, name, region, population (millions), land area (km^2), GDP per capita (thousand USD, approx)
  const COUNTRIES_RAW = [
    ["CN","China","Asia",1410,9600000,13],["IN","India","Asia",1428,3287000,2.6],
    ["ID","Indonesia","Asia",277,1905000,5.0],["PK","Pakistan","Asia",240,881000,1.6],
    ["BD","Bangladesh","Asia",173,148000,2.5],["JP","Japan","Asia",124,378000,34],
    ["PH","Philippines","Asia",117,300000,3.9],["VN","Vietnam","Asia",98,331000,4.3],
    ["IR","Iran","Asia",89,1648000,4.5],["TR","Turkey","Asia",85,783000,13],
    ["TH","Thailand","Asia",72,513000,7],["MM","Myanmar","Asia",54,677000,1.2],
    ["KR","South Korea","Asia",52,100000,34],["IQ","Iraq","Asia",45,438000,5.5],
    ["AF","Afghanistan","Asia",42,652000,0.4],["SA","Saudi Arabia","Asia",36,2150000,32],
    ["UZ","Uzbekistan","Asia",35,449000,2.5],["MY","Malaysia","Asia",34,330000,12],
    ["YE","Yemen","Asia",34,528000,0.6],["NP","Nepal","Asia",30,147000,1.4],
    ["KP","North Korea","Asia",26,121000,1.3],["LK","Sri Lanka","Asia",22,66000,3.8],
    ["KZ","Kazakhstan","Asia",20,2725000,13],["SY","Syria","Asia",18,185000,0.9],
    ["KH","Cambodia","Asia",17,181000,1.8],["JO","Jordan","Asia",11,89000,4.5],
    ["AZ","Azerbaijan","Asia",10,87000,7.5],["AE","United Arab Emirates","Asia",10,84000,50],
    ["TJ","Tajikistan","Asia",10,144000,1.1],["IL","Israel","Asia",9.4,22000,54],
    ["LA","Laos","Asia",7.5,237000,2.0],["SG","Singapore","Asia",5.9,728,85],
    ["LB","Lebanon","Asia",5.5,10000,4],["KG","Kyrgyzstan","Asia",7,200000,1.4],
    ["TM","Turkmenistan","Asia",6.3,488000,8],["KW","Kuwait","Asia",4.3,17800,30],
    ["GE","Georgia","Asia",3.7,70000,7.7],["MN","Mongolia","Asia",3.4,1564000,5],
    ["AM","Armenia","Asia",3.0,30000,8],["QA","Qatar","Asia",2.7,11600,85],
    ["BH","Bahrain","Asia",1.5,780,30],["TL","Timor-Leste","Asia",1.4,15000,1.6],
    ["CY","Cyprus","Asia",1.2,9250,32],["BT","Bhutan","Asia",0.79,38000,3.5],
    ["MV","Maldives","Asia",0.52,300,12],["BN","Brunei","Asia",0.45,5765,32],
    ["OM","Oman","Asia",4.6,309500,19],

    ["NG","Nigeria","Africa",223,923000,2.2],["ET","Ethiopia","Africa",126,1104000,1.1],
    ["EG","Egypt","Africa",112,1002000,4],["CD","DR Congo","Africa",102,2345000,0.65],
    ["TZ","Tanzania","Africa",67,947000,1.2],["ZA","South Africa","Africa",60,1221000,6.5],
    ["KE","Kenya","Africa",55,580000,2.1],["UG","Uganda","Africa",48,242000,1.0],
    ["DZ","Algeria","Africa",45,2382000,4.3],["SD","Sudan","Africa",48,1886000,0.6],
    ["MA","Morocco","Africa",37,447000,3.8],["AO","Angola","Africa",36,1247000,2.9],
    ["MZ","Mozambique","Africa",33,799000,0.5],["GH","Ghana","Africa",34,239000,2.4],
    ["MG","Madagascar","Africa",30,587000,0.5],["CM","Cameroon","Africa",28,475000,1.7],
    ["CI","Ivory Coast","Africa",29,322000,2.7],["NE","Niger","Africa",27,1267000,0.6],
    ["BF","Burkina Faso","Africa",23,274000,0.9],["ML","Mali","Africa",23,1240000,0.9],
    ["MW","Malawi","Africa",20,118000,0.6],["ZM","Zambia","Africa",20,753000,1.3],
    ["SO","Somalia","Africa",18,638000,0.5],["SN","Senegal","Africa",18,197000,1.7],
    ["TD","Chad","Africa",18,1284000,0.7],["ZW","Zimbabwe","Africa",16,391000,1.7],
    ["GN","Guinea","Africa",14,246000,1.2],["RW","Rwanda","Africa",14,26000,1.0],
    ["BJ","Benin","Africa",13,115000,1.4],["BI","Burundi","Africa",13,28000,0.24],
    ["TN","Tunisia","Africa",12,164000,3.8],["SS","South Sudan","Africa",11,644000,0.4],
    ["TG","Togo","Africa",8.7,57000,1.0],["SL","Sierra Leone","Africa",8.5,72000,0.5],
    ["LY","Libya","Africa",6.9,1760000,7],["CG","Congo","Africa",6.0,342000,2.2],
    ["LR","Liberia","Africa",5.4,111000,0.7],["CF","Central African Republic","Africa",5.6,623000,0.5],
    ["MR","Mauritania","Africa",4.9,1031000,2.2],["ER","Eritrea","Africa",3.7,117000,0.7],
    ["NA","Namibia","Africa",2.6,824000,5],["GM","Gambia","Africa",2.7,11000,0.8],
    ["BW","Botswana","Africa",2.6,582000,7.5],["GA","Gabon","Africa",2.4,268000,9],
    ["LS","Lesotho","Africa",2.3,30000,1.1],["GW","Guinea-Bissau","Africa",2.1,36000,0.8],
    ["GQ","Equatorial Guinea","Africa",1.7,28000,8],["MU","Mauritius","Africa",1.3,2040,11],
    ["SZ","Eswatini","Africa",1.2,17000,4],["DJ","Djibouti","Africa",1.1,23000,3.5],
    ["KM","Comoros","Africa",0.87,1861,1.6],["CV","Cabo Verde","Africa",0.6,4033,4],
    ["ST","Sao Tome and Principe","Africa",0.23,964,2.5],["SC","Seychelles","Africa",0.1,460,17],

    ["RU","Russia","Europe",144,17098000,14],["DE","Germany","Europe",84,357000,52],
    ["GB","United Kingdom","Europe",67,244000,48],["FR","France","Europe",68,551000,44],
    ["IT","Italy","Europe",59,301000,38],["ES","Spain","Europe",47,506000,32],
    ["UA","Ukraine","Europe",37,603000,5],["PL","Poland","Europe",38,313000,22],
    ["RO","Romania","Europe",19,238000,17],["NL","Netherlands","Europe",17.7,42000,63],
    ["BE","Belgium","Europe",11.7,30500,53],["CZ","Czechia","Europe",10.5,79000,30],
    ["GR","Greece","Europe",10.4,132000,22],["PT","Portugal","Europe",10.3,92000,28],
    ["SE","Sweden","Europe",10.5,450000,56],["HU","Hungary","Europe",9.6,93000,20],
    ["BY","Belarus","Europe",9.4,208000,7.5],["AT","Austria","Europe",9.1,84000,56],
    ["CH","Switzerland","Europe",8.8,41300,100],["RS","Serbia","Europe",6.6,88000,11],
    ["BG","Bulgaria","Europe",6.4,111000,14],["DK","Denmark","Europe",5.9,43000,68],
    ["FI","Finland","Europe",5.5,338000,53],["SK","Slovakia","Europe",5.4,49000,22],
    ["NO","Norway","Europe",5.5,324000,90],["IE","Ireland","Europe",5.1,70000,100],
    ["HR","Croatia","Europe",3.9,57000,20],["BA","Bosnia and Herzegovina","Europe",3.2,51000,8],
    ["MD","Moldova","Europe",2.5,34000,6],["LT","Lithuania","Europe",2.7,65000,28],
    ["MK","North Macedonia","Europe",1.8,25700,7.5],["SI","Slovenia","Europe",2.1,20300,32],
    ["LV","Latvia","Europe",1.8,65000,24],["EE","Estonia","Europe",1.3,45000,30],
    ["ME","Montenegro","Europe",0.62,13800,11],["LU","Luxembourg","Europe",0.66,2586,130],
    ["MT","Malta","Europe",0.53,316,35],["IS","Iceland","Europe",0.39,103000,75],
    ["AD","Andorra","Europe",0.08,468,42],["MC","Monaco","Europe",0.038,2,190],
    ["LI","Liechtenstein","Europe",0.039,160,180],["SM","San Marino","Europe",0.034,61,50],
    ["VA","Vatican City","Europe",0.0008,0.49,0],

    ["US","United States","North America",335,9834000,80],["MX","Mexico","North America",128,1964000,13],
    ["CA","Canada","North America",39,9985000,53],["GT","Guatemala","North America",18,109000,5.5],
    ["CU","Cuba","North America",11,110000,9],["HT","Haiti","North America",11.5,27750,1.7],
    ["DO","Dominican Republic","North America",11.3,48670,10.5],["HN","Honduras","North America",10.4,112000,3],
    ["NI","Nicaragua","North America",6.9,130000,2.5],["SV","El Salvador","North America",6.3,21000,4.9],
    ["CR","Costa Rica","North America",5.2,51100,14],["PA","Panama","North America",4.4,75000,18],
    ["JM","Jamaica","North America",2.8,10991,5.7],["TT","Trinidad and Tobago","North America",1.5,5130,17],
    ["BS","Bahamas","North America",0.4,13880,35],["BZ","Belize","North America",0.4,22970,7],
    ["BB","Barbados","North America",0.28,430,19],["LC","Saint Lucia","North America",0.18,616,11],
    ["GD","Grenada","North America",0.11,344,10],["VC","Saint Vincent and the Grenadines","North America",0.11,389,8],
    ["AG","Antigua and Barbuda","North America",0.093,442,18],["DM","Dominica","North America",0.072,751,8],
    ["KN","Saint Kitts and Nevis","North America",0.047,261,20],

    ["BR","Brazil","South America",216,8516000,10],["CO","Colombia","South America",52,1142000,7],
    ["AR","Argentina","South America",46,2780000,13],["PE","Peru","South America",34,1285000,7.5],
    ["VE","Venezuela","South America",28,912000,4],["CL","Chile","South America",19.5,756000,17],
    ["EC","Ecuador","South America",18,257000,6.5],["BO","Bolivia","South America",12,1099000,3.5],
    ["PY","Paraguay","South America",6.9,407000,6],["UY","Uruguay","South America",3.4,176000,22],
    ["GY","Guyana","South America",0.81,215000,20],["SR","Suriname","South America",0.61,164000,6],

    ["AU","Australia","Oceania",26,7692000,65],["PG","Papua New Guinea","Oceania",10.3,463000,3],
    ["NZ","New Zealand","Oceania",5.2,268000,48],["FJ","Fiji","Oceania",0.93,18300,5.5],
    ["SB","Solomon Islands","Oceania",0.74,28400,2.4],["VU","Vanuatu","Oceania",0.33,12190,3.2],
    ["WS","Samoa","Oceania",0.22,2831,4.3],["KI","Kiribati","Oceania",0.13,811,1.9],
    ["TO","Tonga","Oceania",0.10,747,5],["FM","Micronesia","Oceania",0.11,702,3.8],
    ["MH","Marshall Islands","Oceania",0.042,181,7],["PW","Palau","Oceania",0.018,459,14],
    ["NR","Nauru","Oceania",0.011,21,12],["TV","Tuvalu","Oceania",0.011,26,5.5]
  ];

  function flagEmoji(code) {
    return code.toUpperCase().replace(/./g, c => String.fromCodePoint(127397 + c.charCodeAt(0)));
  }

  // Real flag images (flagcdn.com) instead of relying on emoji flag support,
  // which several platforms (notably Windows) render as plain letter codes.
  function flagImgUrl(code, px) {
    return "https://flagcdn.com/w" + px + "/" + code.toLowerCase() + ".png";
  }
  function makeFlagImg(code, name, px, className) {
    const img = document.createElement("img");
    img.src = flagImgUrl(code, px);
    img.alt = name + " flag";
    img.className = className;
    img.loading = "lazy";
    img.onerror = function () {
      // offline / blocked network: fall back to the emoji flag as text
      const span = document.createElement("span");
      span.className = className + " flag-fallback";
      span.textContent = flagEmoji(code);
      img.replaceWith(span);
    };
    return img;
  }

  const COUNTRIES = COUNTRIES_RAW.map(([code, name, region, pop, area, gdp]) => ({
    code, name, region, pop, area, gdp, flag: flagEmoji(code)
  }));

  function metricRange(key) {
    const vals = COUNTRIES.map(c => c[key]).filter(v => v > 0);
    return { min: Math.min(...vals), max: Math.max(...vals) };
  }
  const AREA_RANGE = metricRange("area");
  const GDP_RANGE = metricRange("gdp");

  function logPct(value, range) {
    if (!value || value <= 0) return 0;
    const v = Math.max(value, range.min);
    const lo = Math.log(range.min);
    const hi = Math.log(range.max);
    return Math.max(0, Math.min(1, (Math.log(v) - lo) / (hi - lo)));
  }

  const RARITY_BASES = {
    population: {
      label: "population",
      hasMeter: false,
      rarity(c) {
        if (c.pop < 0.06) return "legendary";
        if (c.pop < 1) return "epic";
        if (c.pop < 10) return "rare";
        if (c.pop < 50) return "uncommon";
        return "common";
      },
      format(c) {
        const p = c.pop;
        if (p >= 1000) return "pop ~" + (p / 1000).toFixed(2) + "B";
        if (p >= 1) return "pop ~" + p.toFixed(p < 10 ? 1 : 0) + "M";
        return "pop ~" + Math.round(p * 1000) + "K";
      },
      blurb: "Tier is based on population. The most populous nations (China, India, the US, and so on) are common. Micro-nations with populations under about 60,000 — Vatican City, San Marino, Monaco, Liechtenstein, Nauru, Tuvalu — are legendary."
    },
    area: {
      label: "land area",
      hasMeter: true,
      meterPct(c) { return logPct(c.area, AREA_RANGE); },
      rarity(c) {
        if (c.area < 300) return "legendary";
        if (c.area < 5000) return "epic";
        if (c.area < 50000) return "rare";
        if (c.area < 500000) return "uncommon";
        return "common";
      },
      format(c) {
        const a = c.area;
        if (a >= 1000000) return "area ~" + (a / 1000000).toFixed(1) + "M km²";
        if (a >= 1000) return "area ~" + Math.round(a / 1000) + "K km²";
        return "area ~" + Math.round(a) + " km²";
      },
      blurb: "Tier is based on land area. Vast countries like Russia, Canada, and Australia are common. The tiniest states by area — Vatican City, Monaco, Nauru, Tuvalu, San Marino — are legendary, since you could cross them on foot in minutes."
    },
    gdp: {
      label: "GDP per capita",
      hasMeter: true,
      meterPct(c) { return logPct(c.gdp, GDP_RANGE); },
      rarity(c) {
        if (c.gdp >= 80) return "legendary";
        if (c.gdp >= 40) return "epic";
        if (c.gdp >= 15) return "rare";
        if (c.gdp >= 5) return "uncommon";
        return "common";
      },
      format(c) {
        return "GDP/cap ~$" + c.gdp.toFixed(c.gdp < 10 ? 1 : 0) + "k";
      },
      blurb: "Tier is based on GDP per capita — flipped from the other two modes, since here the rarest finds are the wealthiest. Most of the world's countries have modest income per person, so those are common. A handful of very high-income places (Monaco, Liechtenstein, Luxembourg, Switzerland, Ireland, Norway, Singapore, Qatar) are legendary."
    }
  };

  let countryBasis = "population";
  function applyCountryRarity() {
    const basis = RARITY_BASES[countryBasis];
    COUNTRIES.forEach(c => c.rarity = basis.rarity(c));
    GAMES.countries.pools = buildPools(COUNTRIES);
  }

  const COUNTRY_FACTS = {
    VA: "The smallest country in the world — you could walk across it in about fifteen minutes.",
    MC: "So densely built up that its residents are famously outnumbered by visiting yachts in summer.",
    JP: "A chain of thousands of islands, though most people live on just four of them.",
    BR: "Covers roughly half of South America's landmass and borders nearly every country on the continent.",
    AU: "Both a country and a continent — and the only one that's also a single island.",
    NR: "One of the world's smallest island nations, with no official capital city.",
    RU: "The largest country by land area, spanning eleven time zones.",
    CN: "Home to more people than any country except India, spread across five geographic time zones — though it keeps just one official clock.",
    IN: "The most populous country in the world, home to hundreds of languages.",
    CA: "The second-largest country by area, but most of its population lives within 150 miles of the US border.",
    EG: "Nearly all of its population lives along a single river valley and delta.",
    IS: "One of the most sparsely populated countries in Europe, sitting directly on a volcanic rift.",
    SG: "A city-state so land-constrained it has expanded its territory through land reclamation.",
    CH: "Home to four official languages and no coastline.",
    LU: "One of the world's highest GDP-per-capita figures, thanks partly to its outsized financial sector.",
    QA: "Its income per person is among the world's highest, built largely on natural gas exports."
  };
  const REGION_FACT = {
    Africa: "One of 54 countries across a continent known for its enormous cultural and linguistic diversity.",
    Asia: "Part of the largest and most populous continent on Earth.",
    Europe: "One of dozens of nations packed into a relatively compact continent.",
    "North America": "Part of a continent stretching from the Arctic Circle to the Caribbean.",
    "South America": "Home to the Andes mountain range and the Amazon rainforest.",
    Oceania: "A scattering of islands across the vast Pacific Ocean."
  };

  // ---------- shared roll engine ----------
  const WEIGHTS = { common: 46, uncommon: 28, rare: 16, epic: 7, legendary: 3 };
  const ORDER = ["common", "uncommon", "rare", "epic", "legendary"];

  function buildPools(items) {
    const pools = {};
    ORDER.forEach(r => pools[r] = items.filter(x => x.rarity === r));
    return pools;
  }

  function rollRarity() {
    const total = ORDER.reduce((s, r) => s + WEIGHTS[r], 0);
    let n = Math.random() * total;
    for (const r of ORDER) {
      if (n < WEIGHTS[r]) return r;
      n -= WEIGHTS[r];
    }
    return "common";
  }

  const GAMES = {
    elements: {
      label: "Elements",
      subtitle: "Draw a specimen from the periodic table.",
      items: ELEMENTS,
      pools: buildPools(ELEMENTS),
      key: x => x.z,
      spinLabel: x => x.sym,
      gridCols: 18,
      storageKey: "rarity-roll-discovered-elements",
      hasBasis: false,
      groupLabel: "group",
      groupKey: el => el.cat,
      card(el) {
        return {
          top: "Z — " + el.z,
          big: el.sym,
          name: el.name,
          sub: el.cat.replace("-", " "),
          fact: ELEMENT_FACTS[el.sym] || ELEMENT_CAT_FACT[el.cat]
        };
      }
    },
    countries: {
      label: "Countries",
      subtitle: "Draw a nation from the atlas.",
      items: COUNTRIES,
      pools: buildPools(COUNTRIES),
      key: x => x.code,
      spinLabel: x => x.flag,
      gridCols: 20,
      storageKey: "rarity-roll-discovered-countries",
      hasBasis: true,
      symbolIsFlag: true,
      groupLabel: "continent",
      groupKey: c => c.region,
      card(c) {
        const basis = RARITY_BASES[countryBasis];
        return {
          top: basis.format(c),
          big: c.flag,
          name: c.name,
          sub: c.region,
          fact: COUNTRY_FACTS[c.code] || REGION_FACT[c.region],
          meter: basis.hasMeter ? basis.meterPct(c) : null
        };
      }
    }
  };
  applyCountryRarity();

  function rollItem(game) {
    const r = rollRarity();
    const pool = game.pools[r];
    return pool[Math.floor(Math.random() * pool.length)];
  }

  // ---------- state ----------
  let activeKey = "elements";
  let active = GAMES[activeKey];
  let discovered = {};
  let current = null;
  let resolved = true;
  let maskStamp = false;
  let guessTimer = null;
  let gridSort = "default";

  let streak = 0;
  let bestStreak = 0;
  try { bestStreak = parseInt(localStorage.getItem("rarity-roll-best-streak"), 10) || 0; } catch (e) {}

  function renderStreak() {
    streakCount.textContent = streak;
    bestStreakEl.textContent = bestStreak;
    streakStat.classList.toggle("hot", streak >= 3);
  }

  function loadDiscovered() {
    discovered = {};
    try {
      const saved = localStorage.getItem(active.storageKey);
      if (saved) discovered = JSON.parse(saved);
    } catch (e) {}
  }
  function saveDiscovered() {
    try { localStorage.setItem(active.storageKey, JSON.stringify(discovered)); } catch (e) {}
  }

  // ---------- DOM refs ----------
  const pageTitle = document.getElementById("pageTitle");
  const pageSubtitle = document.getElementById("pageSubtitle");
  const tabs = document.getElementById("tabs");
  const basisRow = document.getElementById("basisRow");
  const basisSeg = document.getElementById("basisSeg");
  const card = document.getElementById("card");
  const rollFace = document.getElementById("rollFace");
  const spinSymbol = document.getElementById("spinSymbol");
  const glowRing = document.getElementById("glowRing");
  const cardBack = document.getElementById("cardBack");
  const cardFront = document.getElementById("cardFront");
  const rollBtn = document.getElementById("rollBtn");
  const guessToggle = document.getElementById("guessToggle");
  const hardToggle = document.getElementById("hardToggle");
  const hardToggleRow = document.getElementById("hardToggleRow");
  const extraHardToggle = document.getElementById("extraHardToggle");
  const extraHardToggleRow = document.getElementById("extraHardToggleRow");
  const guessRow = document.getElementById("guessRow");
  const verdict = document.getElementById("verdict");
  const foundCount = document.getElementById("foundCount");
  const totalCount = document.getElementById("totalCount");
  const lastRarity = document.getElementById("lastRarity");
  const streakStat = document.getElementById("streakStat");
  const streakCount = document.getElementById("streakCount");
  const bestStreakEl = document.getElementById("bestStreak");
  const bestStreakWrap = document.getElementById("bestStreakWrap");
  const sortRow = document.getElementById("sortRow");
  const sortSeg = document.getElementById("sortSeg");
  const sortGroupBtn = document.getElementById("sortGroupBtn");
  const miniGrid = document.getElementById("miniGrid");
  const infoElements = document.getElementById("infoElements");
  const infoCountries = document.getElementById("infoCountries");

  const meterWrap = document.getElementById("meterWrap");
  const meterFill = document.getElementById("meterFill");
  const stampEl = document.getElementById("stamp");
  const zNumEl = document.getElementById("zNum");
  const symbolEl = document.getElementById("symbol");
  const elnameEl = document.getElementById("elname");
  const catEl = document.getElementById("cat");
  const factEl = document.getElementById("fact");

  function getSortedItems() {
    const list = active.items.slice();
    if (gridSort === "rarity") {
      list.sort((a, b) => ORDER.indexOf(a.rarity) - ORDER.indexOf(b.rarity));
    } else if (gridSort === "group" && active.groupKey) {
      list.sort((a, b) => {
        const ka = active.groupKey(a), kb = active.groupKey(b);
        return ka < kb ? -1 : ka > kb ? 1 : 0;
      });
    }
    return list;
  }

  function buildGrid() {
    miniGrid.innerHTML = "";
    miniGrid.style.gridTemplateColumns = "repeat(" + active.gridCols + ", 1fr)";
    getSortedItems().forEach(item => {
      const c = document.createElement("div");
      c.className = "cell";
      c.id = "cell-" + active.key(item);
      miniGrid.appendChild(c);
    });
  }

  function refreshGrid() {
    let count = 0;
    active.items.forEach(item => {
      const c = document.getElementById("cell-" + active.key(item));
      c.className = "cell" + (active.symbolIsFlag ? " flagged" : "");
      c.innerHTML = "";
      if (discovered[active.key(item)]) {
        c.classList.add("found", item.rarity);
        c.title = item.name + " — " + item.rarity;
        if (active.symbolIsFlag) {
          c.appendChild(makeFlagImg(item.code, item.name, 20, "flag-img flag-img-cell"));
        }
        count++;
      } else {
        c.removeAttribute("title");
      }
    });
    foundCount.textContent = count;
    totalCount.textContent = active.items.length;
  }

  miniGrid.addEventListener("click", (e) => {
    const cell = e.target.closest(".cell.found");
    if (!cell) return;
    const key = cell.id.slice(5);
    const item = active.items.find(x => String(active.key(x)) === key);
    if (!item) return;

    if (guessTimer) { clearTimeout(guessTimer); guessTimer = null; }
    current = item;
    resolved = true;
    maskStamp = false;
    card.classList.remove("rolling");
    rollFace.classList.remove("show");
    guessRow.classList.remove("show");
    verdict.classList.remove("show", "correct", "wrong");
    reveal(item);
    rollBtn.disabled = false;
  });

  function showBack() {
    cardBack.style.display = "flex";
    cardFront.classList.remove("show");
    verdict.classList.remove("show", "correct", "wrong");
  }

  function reveal(item) {
    const c = active.card(item);
    cardBack.style.display = "none";
    cardFront.classList.add("show");
    symbolEl.innerHTML = "";
    if (active.symbolIsFlag) {
      symbolEl.appendChild(makeFlagImg(item.code, item.name, 80, "flag-img flag-img-big"));
    } else {
      symbolEl.textContent = c.big;
    }

    const guessPending = maskStamp && !resolved;
    const hideBasis = guessPending && hardToggle.checked;
    const hideText = guessPending && extraHardToggle.checked;

    elnameEl.textContent = hideText ? "?" : c.name;
    catEl.textContent = hideText ? "" : c.sub;
    factEl.textContent = hideText
      ? "Extra hard mode: only the picture is shown — guess the tier from that alone."
      : c.fact;

    // In hard mode, the stat the rarity is actually based on (population,
    // area, GDP/capita, atomic number...) is the tell for guessing, so hide
    // it — along with its meter bar — for as long as the guess is live.
    if (hideBasis) {
      zNumEl.textContent = "— hidden —";
      meterWrap.style.display = "none";
    } else {
      zNumEl.textContent = c.top;
      if (c.meter != null) {
        meterWrap.style.display = "block";
        meterFill.style.width = Math.round(c.meter * 100) + "%";
      } else {
        meterWrap.style.display = "none";
      }
    }

    if (maskStamp) {
      stampEl.textContent = "?";
      stampEl.className = "stamp unknown";
    } else {
      stampEl.textContent = item.rarity;
      stampEl.className = "stamp " + item.rarity;
    }

    discovered[active.key(item)] = true;
    saveDiscovered();
    refreshGrid();
    lastRarity.textContent = "last: " + item.rarity;

    if (!maskStamp && (item.rarity === "rare" || item.rarity === "epic" || item.rarity === "legendary")) {
      pulseGlow(item.rarity);
    }
  }

  function pulseGlow(rarity) {
    glowRing.className = "glow-ring " + rarity;
    void glowRing.offsetWidth;
    glowRing.classList.add("pulse");
  }

  function spinAndRoll() {
    rollBtn.disabled = true;
    guessRow.classList.remove("show");
    verdict.classList.remove("show", "correct", "wrong");
    glowRing.classList.remove("pulse");
    if (guessTimer) { clearTimeout(guessTimer); guessTimer = null; }

    cardBack.style.display = "none";
    cardFront.classList.remove("show");
    rollFace.classList.add("show");
    card.classList.add("rolling");

    const totalMs = 760;
    const start = performance.now();

    function tick(now) {
      const elapsed = now - start;
      const r = active.items[Math.floor(Math.random() * active.items.length)];
      spinSymbol.textContent = active.spinLabel(r);
      spinSymbol.classList.remove("tick");
      void spinSymbol.offsetWidth;
      spinSymbol.classList.add("tick");

      if (elapsed < totalMs) {
        const progress = elapsed / totalMs;
        const delay = 45 + progress * progress * 160;
        setTimeout(() => requestAnimationFrame(tick), delay);
      } else {
        card.classList.remove("rolling");
        rollFace.classList.remove("show");
        settle();
      }
    }
    requestAnimationFrame(tick);
  }

  function settle() {
    current = rollItem(active);
    resolved = false;
    maskStamp = guessToggle.checked;
    reveal(current);

    if (maskStamp) {
      // let the player see the item on its own for a moment before the
      // guess options appear, so it's the rarity being guessed —
      // not the identity of what was just rolled.
      rollBtn.disabled = true;
      guessTimer = setTimeout(() => {
        if (!resolved) guessRow.classList.add("show");
      }, 550);
    } else {
      rollBtn.disabled = false;
    }
  }

  guessRow.addEventListener("click", (e) => {
    const btn = e.target.closest(".guess-btn");
    if (!btn || resolved || !current) return;
    resolved = true;
    guessRow.classList.remove("show");
    const guess = btn.dataset.r;
    const correct = guess === current.rarity;
    verdict.classList.add("show", correct ? "correct" : "wrong");
    verdict.textContent = correct
      ? "Correct — it's " + current.rarity + "."
      : "Not quite — you said " + guess + ", it's actually " + current.rarity + ".";

    if (correct) {
      streak++;
      if (streak > bestStreak) {
        bestStreak = streak;
        try { localStorage.setItem("rarity-roll-best-streak", String(bestStreak)); } catch (e) {}
      }
    } else {
      streak = 0;
    }
    renderStreak();

    // reveal whatever hard mode was hiding, now that the guess is locked in
    reveal(current);

    stampEl.textContent = current.rarity;
    stampEl.className = "stamp " + current.rarity;
    if (current.rarity === "rare" || current.rarity === "epic" || current.rarity === "legendary") {
      pulseGlow(current.rarity);
    }
    rollBtn.disabled = false;
  });

  rollBtn.addEventListener("click", spinAndRoll);

  guessToggle.addEventListener("change", () => {
    hardToggleRow.style.display = guessToggle.checked ? "flex" : "none";
    streakStat.style.display = guessToggle.checked ? "inline" : "none";
    if (!guessToggle.checked) {
      hardToggle.checked = false;
      extraHardToggleRow.style.display = "none";
      extraHardToggle.checked = false;
    }
  });

  hardToggle.addEventListener("change", () => {
    extraHardToggleRow.style.display = hardToggle.checked ? "flex" : "none";
    if (!hardToggle.checked) extraHardToggle.checked = false;
  });

  function updateInfoText() {
    if (activeKey === "elements") {
      infoElements.style.display = "block";
      infoCountries.style.display = "none";
    } else {
      infoElements.style.display = "none";
      infoCountries.style.display = "block";
      infoCountries.textContent = RARITY_BASES[countryBasis].blurb;
    }
  }

  function renderSortSeg() {
    Array.from(sortSeg.children).forEach(btn => {
      btn.classList.toggle("active", btn.dataset.sort === gridSort);
    });
  }

  sortSeg.addEventListener("click", (e) => {
    const btn = e.target.closest(".basis-btn");
    if (!btn) return;
    gridSort = btn.dataset.sort;
    renderSortSeg();
    buildGrid();
    refreshGrid();
  });

  function renderBasisSeg() {
    Array.from(basisSeg.children).forEach(btn => {
      btn.classList.toggle("active", btn.dataset.basis === countryBasis);
    });
  }

  basisSeg.addEventListener("click", (e) => {
    const btn = e.target.closest(".basis-btn");
    if (!btn) return;
    countryBasis = btn.dataset.basis;
    renderBasisSeg();
    applyCountryRarity();
    refreshGrid();
    updateInfoText();
    if (current && !maskStamp && cardFront.classList.contains("show") && activeKey === "countries") {
      reveal(current);
    }
  });

  function setActiveTab(key) {
    activeKey = key;
    active = GAMES[key];
    resolved = true;
    current = null;
    maskStamp = false;
    if (guessTimer) { clearTimeout(guessTimer); guessTimer = null; }

    Array.from(tabs.children).forEach(btn => {
      btn.classList.toggle("active", btn.dataset.game === key);
    });
    pageTitle.textContent = "Rarity Roll";
    pageSubtitle.textContent = active.subtitle;
    rollBtn.textContent = "Roll a" + (key === "elements" ? "n element" : " country");
    guessRow.classList.remove("show");
    verdict.classList.remove("show", "correct", "wrong");
    glowRing.classList.remove("pulse");
    basisRow.style.display = active.hasBasis ? "flex" : "none";
    updateInfoText();

    sortGroupBtn.textContent = active.groupLabel || "group";
    renderSortSeg();

    loadDiscovered();
    buildGrid();
    refreshGrid();
    showBack();
    rollBtn.disabled = false;
  }

  tabs.addEventListener("click", (e) => {
    const btn = e.target.closest(".tab-btn");
    if (!btn) return;
    setActiveTab(btn.dataset.game);
  });

  renderBasisSeg();
  renderSortSeg();
  renderStreak();
  setActiveTab("elements");
})();
